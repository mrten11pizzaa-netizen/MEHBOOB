// ===== Mobile Menu Toggle =====
function toggleMobileMenu() {
    const mobileMenu = document.getElementById('mobileMenu');
    mobileMenu.classList.toggle('active');
}

// ===== Smooth Scrolling for Navigation Links =====
document.addEventListener('DOMContentLoaded', function() {
    const navLinks = document.querySelectorAll('a[href^="#"]');
    
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.getAttribute('href');
            if (targetId === '#') return;
            
            const targetSection = document.querySelector(targetId);
            if (targetSection) {
                const navHeight = document.querySelector('.navbar').offsetHeight;
                const targetPosition = targetSection.offsetTop - navHeight;
                
                window.scrollTo({
                    top: targetPosition,
                    behavior: 'smooth'
                });
            }
        });
    });
});

// ===== Scroll to Top Button =====
const scrollTopBtn = document.getElementById('scrollTop');

window.addEventListener('scroll', function() {
    if (window.pageYOffset > 300) {
        scrollTopBtn.classList.add('visible');
    } else {
        scrollTopBtn.classList.remove('visible');
    }
});

function scrollToTop() {
    window.scrollTo({
        top: 0,
        behavior: 'smooth'
    });
}

// ===== Menu Filter Function =====
function filterMenu(category) {
    const allCategories = document.querySelectorAll('.menu-category');
    const allButtons = document.querySelectorAll('.category-btn');
    
    // Remove active class from all buttons
    allButtons.forEach(btn => btn.classList.remove('active'));
    
    // Add active class to clicked button
    event.target.closest('.category-btn').classList.add('active');
    
    // Filter menu categories
    if (category === 'all') {
        allCategories.forEach(cat => {
            cat.style.display = 'block';
            cat.style.animation = 'fadeInUp 0.5s ease';
        });
    } else {
        allCategories.forEach(cat => {
            const categoryType = cat.getAttribute('data-category');
            if (categoryType === category) {
                cat.style.display = 'block';
                cat.style.animation = 'fadeInUp 0.5s ease';
            } else {
                cat.style.display = 'none';
            }
        });
    }
}

// ===== Call Restaurant Function =====
function callRestaurant() {
    // Primary phone number
    const phoneNumber = '03137300725';
    window.location.href = `tel:${phoneNumber}`;
}

// ===== Order Now Function =====
function orderNow() {
    // Scroll to deals section or call restaurant
    const dealsSection = document.getElementById('deals');
    if (dealsSection) {
        const navHeight = document.querySelector('.navbar').offsetHeight;
        const targetPosition = dealsSection.offsetTop - navHeight;
        
        window.scrollTo({
            top: targetPosition,
            behavior: 'smooth'
        });
    }
}

// ===== Check if Restaurant is Open =====
function checkRestaurantStatus() {
    const statusBadge = document.querySelector('.status-badge');
    if (!statusBadge) return;
    
    const now = new Date();
    const currentHour = now.getHours();
    
    // Restaurant timing: 12 PM (12:00) to 3 AM (03:00)
    // Open from 12:00 to 23:59 and 00:00 to 03:00
    const isOpen = (currentHour >= 12 && currentHour <= 23) || (currentHour >= 0 && currentHour < 3);
    
    if (isOpen) {
        statusBadge.textContent = 'Abhi Khula Hai ✓';
        statusBadge.classList.add('open');
        statusBadge.classList.remove('closed');
    } else {
        statusBadge.textContent = 'Band Hai ✗';
        statusBadge.classList.remove('open');
        statusBadge.classList.add('closed');
    }
}

// ===== Navbar Scroll Effect =====
let lastScroll = 0;
const navbar = document.querySelector('.navbar');

window.addEventListener('scroll', function() {
    const currentScroll = window.pageYOffset;
    
    if (currentScroll > 100) {
        navbar.style.padding = '0.5rem 0';
        navbar.style.boxShadow = '0 4px 20px rgba(0, 0, 0, 0.2)';
    } else {
        navbar.style.padding = '1rem 0';
        navbar.style.boxShadow = '0 4px 15px rgba(0, 0, 0, 0.1)';
    }
    
    lastScroll = currentScroll;
});

// ===== Animate Elements on Scroll =====
function animateOnScroll() {
    const elements = document.querySelectorAll('.deal-card, .menu-item, .info-card, .contact-card');
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '0';
                entry.target.style.transform = 'translateY(30px)';
                
                setTimeout(() => {
                    entry.target.style.transition = 'all 0.6s ease';
                    entry.target.style.opacity = '1';
                    entry.target.style.transform = 'translateY(0)';
                }, 100);
                
                observer.unobserve(entry.target);
            }
        });
    }, {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    });
    
    elements.forEach(element => {
        observer.observe(element);
    });
}

// ===== Deal Card Click Effect =====
document.addEventListener('DOMContentLoaded', function() {
    const dealCards = document.querySelectorAll('.deal-card');
    
    dealCards.forEach(card => {
        card.addEventListener('click', function() {
            // Add a click effect
            this.style.transform = 'scale(0.98)';
            setTimeout(() => {
                this.style.transform = '';
            }, 200);
            
            // Could open a modal or call function here
            console.log('Deal clicked:', this.querySelector('h3').textContent);
        });
    });
});

// ===== Menu Item Hover Effect =====
document.addEventListener('DOMContentLoaded', function() {
    const menuItems = document.querySelectorAll('.menu-item');
    
    menuItems.forEach(item => {
        item.addEventListener('mouseenter', function() {
            const icon = this.querySelector('.menu-icon');
            if (icon) {
                icon.style.transform = 'scale(1.2) rotate(10deg)';
                icon.style.transition = 'transform 0.3s ease';
            }
        });
        
        item.addEventListener('mouseleave', function() {
            const icon = this.querySelector('.menu-icon');
            if (icon) {
                icon.style.transform = 'scale(1) rotate(0deg)';
            }
        });
    });
});

// ===== Add WhatsApp Floating Button Functionality =====
function createWhatsAppButton() {
    const whatsappBtn = document.createElement('a');
    whatsappBtn.href = 'https://wa.me/923137300725?text=Assalam%20o%20Alaikum!%20Main%20order%20karna%20chahta%20hoon';
    whatsappBtn.target = '_blank';
    whatsappBtn.className = 'whatsapp-float';
    whatsappBtn.innerHTML = '<i class="fab fa-whatsapp"></i>';
    whatsappBtn.title = 'WhatsApp par order karein';
    
    document.body.appendChild(whatsappBtn);
    
    // Add CSS for WhatsApp button
    const style = document.createElement('style');
    style.textContent = `
        .whatsapp-float {
            position: fixed;
            bottom: 100px;
            right: 30px;
            width: 60px;
            height: 60px;
            background: #25D366;
            color: white;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 2rem;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.3);
            z-index: 998;
            transition: all 0.3s ease;
            text-decoration: none;
            animation: pulse 2s infinite;
        }
        
        .whatsapp-float:hover {
            transform: scale(1.1);
            background: #128C7E;
        }
        
        @media (max-width: 768px) {
            .whatsapp-float {
                width: 50px;
                height: 50px;
                font-size: 1.5rem;
                bottom: 90px;
                right: 20px;
            }
        }
    `;
    document.head.appendChild(style);
}

// ===== Initialize All Functions =====
document.addEventListener('DOMContentLoaded', function() {
    checkRestaurantStatus();
    animateOnScroll();
    createWhatsAppButton();
    
    // Update restaurant status every minute
    setInterval(checkRestaurantStatus, 60000);
});

// ===== Close mobile menu when clicking outside =====
document.addEventListener('click', function(event) {
    const mobileMenu = document.getElementById('mobileMenu');
    const menuBtn = document.querySelector('.mobile-menu-btn');
    
    if (mobileMenu && mobileMenu.classList.contains('active')) {
        if (!mobileMenu.contains(event.target) && !menuBtn.contains(event.target)) {
            mobileMenu.classList.remove('active');
        }
    }
});

// ===== Prevent closing menu when clicking inside =====
document.getElementById('mobileMenu')?.addEventListener('click', function(event) {
    if (event.target.tagName === 'A') {
        this.classList.remove('active');
    }
});

// ===== Add loading animation =====
window.addEventListener('load', function() {
    document.body.style.opacity = '0';
    document.body.style.transition = 'opacity 0.5s ease';
    
    setTimeout(() => {
        document.body.style.opacity = '1';
    }, 100);
});

// ===== Console Welcome Message =====
console.log('%c🍕 Ten 11 Pizza Website', 'color: #e74c3c; font-size: 24px; font-weight: bold;');
console.log('%cWelcome to Ten 11 Pizza! 🍕', 'color: #f39c12; font-size: 16px;');
console.log('%cOpen: 12 PM to 3 AM', 'color: #27ae60; font-size: 14px;');
console.log('%cCall us: 0313-7300725 | 0347-6300725', 'color: #3498db; font-size: 14px;');
